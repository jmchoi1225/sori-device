#include <Sori_Serial.h>

void SoriSerial::begin(){
    if (!BLE.begin()){
        while (1);
    }

    BLE.setDeviceName(nameOfPeripheral);
    BLE.setLocalName(nameOfPeripheral);
    BLE.setAdvertisedService(dataService);
    dataService.addCharacteristic(rxChar);
    dataService.addCharacteristic(txChar);

    BLE.addService(dataService);

    // Bluetooth LE connection handlers.
    BLE.setEventHandler(BLEConnected, onBLEConnected);
    BLE.setEventHandler(BLEDisconnected, onBLEDisconnected);

    // Event driven reads.
    rxChar.setEventHandler(BLEWritten, onRxCharValueUpdate);
    
    receivedMessage = EMPTY_MESSAGE;
    connected = false;
    
    BLE.advertise();
}

void SoriSerial::poll(){
    BLE.poll();
}


String SoriSerial::read(){
    String message = receivedMessage;
    receivedMessage = EMPTY_MESSAGE;
    return message;
}

void SoriSerial::write(String message){
    uint8_t data[256];
    message.getBytes(data, message.length());
    txChar.writeValue(data, message.length());
}

void SoriSerial::onConnect(){
    connected = true;
}

void SoriSerial::onDisconnect(){
    connected = false;
}

void SoriSerial::onReceiveMessage(BLEDevice central, BLECharacteristic characteristic){
    receivedMessage = reinterpret_cast<const char*>(rxChar.value());
}

